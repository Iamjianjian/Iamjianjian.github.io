$ N=114514 # just for test. find out the true value here
$ echo $N
114514
$ gcc -DN=$N -O2 -c div.c -o div.o
$ objdump -d -mi386:x86-64:intel div.o

div.o:     file format elf64-x86-64


Disassembly of section .text:

0000000000000000 <mod>:
   0:   48 89 f8                mov    rax,rdi
   3:   48 ba 0b 4e e9 b3 e9    movabs rdx,0x24a082e9b3e94e0b
   a:   82 a0 24
   d:   48 c1 ff 3f             sar    rdi,0x3f
  11:   48 f7 ea                imul   rdx
  14:   48 c1 fa 0e             sar    rdx,0xe
  18:   48 89 d0                mov    rax,rdx
  1b:   48 29 f8                sub    rax,rdi
  1e:   c3                      ret
$ echo flag is Aurora{$N}

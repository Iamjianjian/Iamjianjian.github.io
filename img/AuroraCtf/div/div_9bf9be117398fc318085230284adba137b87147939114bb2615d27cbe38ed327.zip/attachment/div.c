long long mod(long long numerator){
    long long denominator, remainder;
    denominator = N;
    remainder = numerator / denominator;
    return remainder;
}
